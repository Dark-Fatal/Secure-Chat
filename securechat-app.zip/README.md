# SecureChat

Application de messagerie sécurisée (Flutter + Firebase).
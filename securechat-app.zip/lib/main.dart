import 'package:flutter/material.dart';

void main() {
  runApp(SecureChatApp());
}

class SecureChatApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SecureChat',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: Scaffold(
        appBar: AppBar(title: Text('SecureChat')),
        body: Center(child: Text('Bienvenue sur SecureChat !')),
      ),
    );
  }
}
